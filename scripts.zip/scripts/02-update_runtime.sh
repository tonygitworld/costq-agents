#!/bin/bash
set -e

# ============================================================
# CostQ AgentCore Runtime 更新脚本（保留环境变量版本）
# ============================================================
# 功能：
# 1. 自动获取当前 Runtime 配置（环境变量、网络配置、角色等）
# 2. 仅更新镜像 URI，保留所有其他配置
# 3. 验证更新成功
#
# 使用方法：
#   ./02-update_runtime.sh <image-tag> [runtime-id]
#
#   参数说明：
#     image-tag   : 必填，镜像标签（如 v20251225-111957）
#     runtime-id  : 可选，Runtime ID（默认：开发环境）
#
#   示例：
#     # 更新开发环境（使用默认 Runtime ID）
#     ./02-update_runtime.sh v20251225-111957
#
#     # 更新生产环境（指定 Runtime ID）
#     ./02-update_runtime.sh v20251225-111957 cosq_agentcore_runtime_production-5x9j6eBjmZ
# ============================================================

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# jq 命令路径（macOS Homebrew）
JQ="/opt/homebrew/bin/jq"

# 检查 jq 是否存在
if [ ! -f "$JQ" ]; then
    echo -e "${RED}❌ 错误：jq 命令未找到${NC}"
    echo "预期路径: $JQ"
    echo ""
    echo "请安装 jq："
    echo "  brew install jq"
    exit 1
fi

# 配置
DEFAULT_RUNTIME_ID="costq_agents_development_lyg-glOijp2Jdm"  # 默认：开发环境
ECR_REPO="000451883532.dkr.ecr.ap-northeast-1.amazonaws.com/costq-agents"
AWS_REGION="ap-northeast-1"
AWS_PROFILE="3532"

# 检查参数
if [ -z "$1" ]; then
    echo -e "${RED}❌ 错误：缺少镜像标签参数${NC}"
    echo ""
    echo "使用方法: $0 <image-tag> [runtime-id]"
    echo ""
    echo "参数说明："
    echo "  image-tag   : 必填，镜像标签（如 v20251225-111957）"
    echo "  runtime-id  : 可选，Runtime ID（默认：开发环境）"
    echo ""
    echo "示例："
    echo "  # 更新开发环境（使用默认 Runtime ID）"
    echo "  $0 v20251225-111957"
    echo ""
    echo "  # 更新生产环境（指定 Runtime ID）"
    echo "  $0 v20251225-111957 cosq_agentcore_runtime_production-5x9j6eBjmZ"
    echo ""
    exit 1
fi

IMAGE_TAG="$1"
RUNTIME_ID="${2:-$DEFAULT_RUNTIME_ID}"  # 如果未提供第二个参数，使用默认值
NEW_IMAGE_URI="${ECR_REPO}:${IMAGE_TAG}"

echo -e "${GREEN}🚀 开始更新 AgentCore Runtime${NC}"
echo "Runtime ID: ${RUNTIME_ID}"
echo "新镜像: ${NEW_IMAGE_URI}"
echo ""

# Step 1: 获取当前 Runtime 配置
echo -e "${YELLOW}📥 Step 1: 获取当前 Runtime 配置...${NC}"
TEMP_FILE="/tmp/runtime_config_$(date +%s).json"
aws bedrock-agentcore-control get-agent-runtime \
  --agent-runtime-id "${RUNTIME_ID}" \
  --region "${AWS_REGION}" \
  --profile "${AWS_PROFILE}" \
  --output json > "${TEMP_FILE}"

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ 获取 Runtime 配置失败${NC}"
    exit 1
fi

# 提取当前配置
CURRENT_VERSION=$($JQ -r '.agentRuntimeVersion' "${TEMP_FILE}")
ROLE_ARN=$($JQ -r '.roleArn' "${TEMP_FILE}")
NETWORK_CONFIG=$($JQ -c '.networkConfiguration' "${TEMP_FILE}")
ENV_VARS=$($JQ -c '.environmentVariables // {}' "${TEMP_FILE}")

echo -e "${GREEN}✅ 当前配置：${NC}"
echo "  版本: ${CURRENT_VERSION}"
echo "  角色: ${ROLE_ARN}"
echo "  环境变量数量: $(echo "${ENV_VARS}" | $JQ 'length')"
echo ""

# Step 2: 构建更新请求
echo -e "${YELLOW}🔧 Step 2: 构建更新请求...${NC}"

# 创建 artifact JSON
ARTIFACT_JSON=$(cat <<EOF
{
  "containerConfiguration": {
    "containerUri": "${NEW_IMAGE_URI}"
  }
}
EOF
)

echo "${ARTIFACT_JSON}" > /tmp/artifact_update.json

# 提取网络配置参数
NETWORK_MODE=$(echo "${NETWORK_CONFIG}" | $JQ -r '.networkMode')
if [ "${NETWORK_MODE}" == "VPC" ]; then
    SECURITY_GROUPS=$(echo "${NETWORK_CONFIG}" | $JQ -r '.networkModeConfig.securityGroups | join(",")')
    SUBNETS=$(echo "${NETWORK_CONFIG}" | $JQ -r '.networkModeConfig.subnets | join(",")')
    NETWORK_ARG="networkMode=VPC,networkModeConfig={securityGroups=[${SECURITY_GROUPS}],subnets=[${SUBNETS}]}"
else
    NETWORK_ARG="networkMode=${NETWORK_MODE}"
fi

echo -e "${GREEN}✅ 更新请求已准备${NC}"
echo ""

# Step 3: 执行更新
echo -e "${YELLOW}⚙️  Step 3: 执行 Runtime 更新...${NC}"
UPDATE_RESULT=$(aws bedrock-agentcore-control update-agent-runtime \
  --agent-runtime-id "${RUNTIME_ID}" \
  --agent-runtime-artifact file:///tmp/artifact_update.json \
  --role-arn "${ROLE_ARN}" \
  --network-configuration "${NETWORK_ARG}" \
  --environment-variables "${ENV_VARS}" \
  --region "${AWS_REGION}" \
  --profile "${AWS_PROFILE}" \
  --output json)

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Runtime 更新失败${NC}"
    exit 1
fi

NEW_VERSION=$(echo "${UPDATE_RESULT}" | $JQ -r '.agentRuntimeVersion')
UPDATE_STATUS=$(echo "${UPDATE_RESULT}" | $JQ -r '.status')

echo -e "${GREEN}✅ 更新已提交${NC}"
echo "  新版本: ${NEW_VERSION} (从 ${CURRENT_VERSION} 升级)"
echo "  状态: ${UPDATE_STATUS}"
echo ""

# Step 4: 等待更新完成
echo -e "${YELLOW}⏳ Step 4: 等待更新完成（最多等待60秒）...${NC}"
MAX_WAIT=60
WAITED=0
while [ ${WAITED} -lt ${MAX_WAIT} ]; do
    sleep 5
    WAITED=$((WAITED + 5))

    STATUS=$(aws bedrock-agentcore-control get-agent-runtime \
      --agent-runtime-id "${RUNTIME_ID}" \
      --region "${AWS_REGION}" \
      --profile "${AWS_PROFILE}" \
      --output json | $JQ -r '.status')

    if [ "${STATUS}" == "READY" ]; then
        echo -e "${GREEN}✅ Runtime 更新完成！${NC}"
        break
    fi

    echo "  等待中... (${WAITED}s, 状态: ${STATUS})"
done

if [ "${STATUS}" != "READY" ]; then
    echo -e "${RED}❌ 更新超时，请手动检查 Runtime 状态${NC}"
    exit 1
fi

# Step 5: 验证更新
echo ""
echo -e "${YELLOW}🔍 Step 5: 验证更新结果...${NC}"
FINAL_CONFIG=$(aws bedrock-agentcore-control get-agent-runtime \
  --agent-runtime-id "${RUNTIME_ID}" \
  --region "${AWS_REGION}" \
  --profile "${AWS_PROFILE}" \
  --output json)

FINAL_IMAGE=$(echo "${FINAL_CONFIG}" | $JQ -r '.agentRuntimeArtifact.containerConfiguration.containerUri')
FINAL_ENV_VARS=$(echo "${FINAL_CONFIG}" | $JQ -c '.environmentVariables // {}')
FINAL_ROLE_ARN=$(echo "${FINAL_CONFIG}" | $JQ -r '.roleArn')
FINAL_NETWORK_CONFIG=$(echo "${FINAL_CONFIG}" | $JQ -c '.networkConfiguration')

echo -e "${GREEN}✅ 验证基本信息：${NC}"
echo "  镜像: ${FINAL_IMAGE}"
echo "  环境变量数量: $(echo "${FINAL_ENV_VARS}" | $JQ 'length') 个（原: $(echo "${ENV_VARS}" | $JQ 'length') 个）"
echo "  IAM 角色: ${FINAL_ROLE_ARN}"
echo ""

# 验证镜像更新
if [ "${FINAL_IMAGE}" == "${NEW_IMAGE_URI}" ]; then
    echo -e "${GREEN}✅ 镜像更新成功！${NC}"
else
    echo -e "${RED}❌ 镜像更新失败！${NC}"
    echo "  期望: ${NEW_IMAGE_URI}"
    echo "  实际: ${FINAL_IMAGE}"
    exit 1
fi

# 验证 IAM 角色是否保持不变
if [ "${FINAL_ROLE_ARN}" == "${ROLE_ARN}" ]; then
    echo -e "${GREEN}✅ IAM 角色已保留！${NC}"
else
    echo -e "${RED}❌ IAM 角色发生变化！${NC}"
    echo "  原值: ${ROLE_ARN}"
    echo "  新值: ${FINAL_ROLE_ARN}"
    exit 1
fi

# 验证网络配置是否保持不变
if [ "${FINAL_NETWORK_CONFIG}" == "${NETWORK_CONFIG}" ]; then
    echo -e "${GREEN}✅ 网络配置已保留！${NC}"
else
    echo -e "${YELLOW}⚠️  网络配置发生变化${NC}"
    echo "  原配置: ${NETWORK_CONFIG}"
    echo "  新配置: ${FINAL_NETWORK_CONFIG}"
fi

# 验证环境变量数量
ORIGINAL_ENV_COUNT=$(echo "${ENV_VARS}" | $JQ 'length')
FINAL_ENV_COUNT=$(echo "${FINAL_ENV_VARS}" | $JQ 'length')

if [ "${FINAL_ENV_COUNT}" -eq "${ORIGINAL_ENV_COUNT}" ]; then
    echo -e "${GREEN}✅ 环境变量数量一致！${NC}"
else
    echo -e "${YELLOW}⚠️  环境变量数量发生变化（${ORIGINAL_ENV_COUNT} → ${FINAL_ENV_COUNT}）${NC}"
fi

# 验证每个环境变量的值
echo ""
echo -e "${YELLOW}🔍 验证环境变量详情：${NC}"
ENV_CHANGED=0
for key in $(echo "${ENV_VARS}" | $JQ -r 'keys[]'); do
    ORIGINAL_VALUE=$(echo "${ENV_VARS}" | $JQ -r ".\"${key}\"")
    FINAL_VALUE=$(echo "${FINAL_ENV_VARS}" | $JQ -r ".\"${key}\"")

    if [ "${ORIGINAL_VALUE}" != "${FINAL_VALUE}" ]; then
        ENV_CHANGED=1
        echo -e "${RED}  ❌ ${key}: 值已变化${NC}"
        echo "     原值: ${ORIGINAL_VALUE}"
        echo "     新值: ${FINAL_VALUE}"
    else
        # 对于敏感信息（如密钥），只显示前几个字符
        if [[ "${key}" == *"KEY"* ]] || [[ "${key}" == *"SECRET"* ]]; then
            DISPLAY_VALUE="${ORIGINAL_VALUE:0:20}..."
        else
            DISPLAY_VALUE="${ORIGINAL_VALUE}"
        fi
        echo -e "${GREEN}  ✅ ${key}: ${DISPLAY_VALUE}${NC}"
    fi
done

# 检查是否有新增或删除的环境变量
for key in $(echo "${FINAL_ENV_VARS}" | $JQ -r 'keys[]'); do
    if ! echo "${ENV_VARS}" | $JQ -e ".\"${key}\"" > /dev/null 2>&1; then
        ENV_CHANGED=1
        NEW_VALUE=$(echo "${FINAL_ENV_VARS}" | $JQ -r ".\"${key}\"")
        echo -e "${YELLOW}  ⚠️  ${key}: 新增的环境变量 (值: ${NEW_VALUE})${NC}"
    fi
done

for key in $(echo "${ENV_VARS}" | $JQ -r 'keys[]'); do
    if ! echo "${FINAL_ENV_VARS}" | $JQ -e ".\"${key}\"" > /dev/null 2>&1; then
        ENV_CHANGED=1
        echo -e "${RED}  ❌ ${key}: 环境变量已删除${NC}"
    fi
done

if [ ${ENV_CHANGED} -eq 0 ]; then
    echo -e "${GREEN}✅ 所有环境变量完整保留！${NC}"
else
    echo -e "${YELLOW}⚠️  环境变量存在变化，请确认是否符合预期${NC}"
fi

# 清理临时文件
rm -f "${TEMP_FILE}" /tmp/artifact_update.json

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}🎉 Runtime 更新完成！${NC}"
echo -e "${GREEN}============================================================${NC}"
echo "  Runtime ID: ${RUNTIME_ID}"
echo "  新版本: ${NEW_VERSION}"
echo "  镜像: ${IMAGE_TAG}"
echo ""
echo -e "${YELLOW}📝 下一步：${NC}"
echo "  1. 新建一个会话（点击 'New Chat'）"
echo "  2. 发起查询测试功能"
echo "  3. 检查 CloudWatch 日志验证日志输出"
echo -e "${GREEN}============================================================${NC}"
