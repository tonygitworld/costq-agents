#!/bin/bash
#
# 构建 Docker 镜像并推送到 ECR
#
# 用途：将 CostQ Agent 打包成 ARM64 镜像并上传到 AWS ECR
#
# 使用方法：
#   cd costq-agents/scripts
#   ./01-build_and_push.sh
#

set -e  # 遇到错误立即退出

# =============================================================================
# 配置
# =============================================================================
AWS_PROFILE="3532"
AWS_REGION="ap-northeast-1"
AWS_ACCOUNT="000451883532"
ECR_REPO="costq-agents"
IMAGE_TAG="v$(date +%Y%m%d-%H%M%S)"

# 获取脚本所在目录和项目根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# 计算完整的 ECR URI
ECR_URI="${AWS_ACCOUNT}.dkr.ecr.${AWS_REGION}.amazonaws.com/${ECR_REPO}"
FULL_IMAGE="${ECR_URI}:${IMAGE_TAG}"

# =============================================================================
# 输出横幅
# =============================================================================
echo "============================================================"
echo "🚀 构建并推送 CostQ Agent 镜像"
echo "============================================================"
echo "项目目录: ${PROJECT_ROOT}"
echo "ECR 仓库: ${ECR_URI}"
echo "镜像标签: latest, ${IMAGE_TAG}"
echo "平台: linux/arm64"
echo "============================================================"
echo ""

# =============================================================================
# Step 1: 登录 ECR
# =============================================================================
echo "🔐 Step 1: 登录 ECR..."
AWS_PROFILE=${AWS_PROFILE} aws ecr get-login-password --region ${AWS_REGION} | \
  docker login --username AWS --password-stdin ${AWS_ACCOUNT}.dkr.ecr.${AWS_REGION}.amazonaws.com

if [ $? -eq 0 ]; then
    echo "✅ ECR 登录成功"
    echo ""
else
    echo "❌ ECR 登录失败"
    exit 1
fi

# =============================================================================
# Step 2: 构建 ARM64 镜像
# =============================================================================
echo "🔨 Step 2: 构建 ARM64 Docker 镜像（使用缓存）..."
echo "   ⚠️  首次构建可能需要 5-10 分钟，后续构建会更快..."
echo ""

# 切换到项目根目录
cd "${PROJECT_ROOT}"

docker buildx build \
  --platform linux/arm64 \
  -f scripts/Dockerfile \
  -t ${FULL_IMAGE} \
  --load \
  .

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 镜像构建成功"
    echo ""
else
    echo ""
    echo "❌ 镜像构建失败"
    exit 1
fi

# =============================================================================
# Step 3: 打标签并推送到 ECR
# =============================================================================
echo "🏷️  Step 3: 打标签..."
docker tag ${FULL_IMAGE} ${ECR_URI}:latest
echo "✅ 标签已创建: latest, ${IMAGE_TAG}"
echo ""

echo "📤 Step 4: 推送镜像到 ECR..."
docker push ${FULL_IMAGE}
docker push ${ECR_URI}:latest

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 镜像推送成功"
    echo ""
else
    echo ""
    echo "❌ 镜像推送失败"
    exit 1
fi

# =============================================================================
# 完成
# =============================================================================
echo "============================================================"
echo "✅ 镜像部署完成!"
echo "============================================================"
echo "镜像标签: latest, ${IMAGE_TAG}"
echo "镜像 URI: ${FULL_IMAGE}"
echo ""
echo "📝 下一步："
echo "  运行 ./02-update_runtime.sh ${IMAGE_TAG} 更新 AgentCore Runtime"
echo ""
